import React from 'react'
const Event=props=>{
    const {name,age,salary}=props
    // const display=()=>{
    //     console.log("abc");
    // }
    function display()
    {console.log("clicked")};
    
    return(
        <div>
        <h1>Hi {name} your age is {age} and salary is {salary}</h1>
        <hr/>
        <h2>{name}</h2>
        <button onClick={display}>Click</button>
        </div>
    );

}
export default Event;