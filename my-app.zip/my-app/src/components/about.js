import React,{useState} from 'react';
const About=(props) =>
{
    // console.log(props);
    // return ( 
    // <div>
    //     <h1>Hello {props.name} , {props.age}</h1>
    // {props.children}
    // </div>
    // );
    const [name,setName]= useState('hundai');

const [model,setModel]= useState('2021');

const [condition,setCondition]= useState('Good');





   return(

    <div>

        <h1 id="demo" className="demo1">Hello {props.name} and age is {props.age}</h1>

        {props.children}<hr></hr>

   

    <h1>State</h1>

    <h3>name is {name} and model is {model} with {condition} condition</h3>



    {/* <p> {name}</p>

    <button onClick={()=>{setName('audi')}}>Change</button>  */}

 <button onClick={()=>{setName('audi')}}>Change</button>

</div>
   )
}
export default About;
