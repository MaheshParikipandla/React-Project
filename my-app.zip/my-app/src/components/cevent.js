import React,{Component} from 'react';

class CEvent extends Component{
constructor()
{
super()
this.state={
msg:'welcome'
}
this.display=this.display.bind(this);
}



display(){
console.log(this);
console.log('display function');
this.setState({
msg:'bye'
})
}
render(){
const{name,age}=this.props;
return(
<div>
<h2>hello{name},{age}</h2>
<hr/>
<h1>{this.state.msg}Mahesh</h1>
<button onClick={this.display.bind(this)}>change 1</button>
<button onClick={()=>this.display()}>change 2</button>
{/* recommended method */}
<button onClick={this.display}>change 3</button>



</div>
);
}
}
export default CEvent;