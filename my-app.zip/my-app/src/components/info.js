import { Component } from "react";

class Info extends Component{
    // constructor(props)
    // {
    //     super(props);
    //     // console.log(this.props.name);
    // }
    constructor()
    {
        super()
        // console.log(this.props.name);
        this.state={greet:"welcome Mahesh"}
    }
    changeGreet()
    {
        this.setState=({
            greet:"welcome ganesh"
    });
   }   

    render()
    {
        return(
            <div>
                {/* <h1>This is Class Component  {this.props.name}</h1> */}
                <h1>{this.state.greet} </h1>
                <button onClick={()=>{this.changeGreet()}}>greet</button>
            </div>
        );
    }
}
export default Info;