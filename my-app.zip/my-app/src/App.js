
import './App.css';
import Home from './components/home';
import  Info from './components/info'
import CEvent from './components/cevent';
import About from './components/about';
import Event from './components/event';
import { Component } from 'react';
import FormComponent from './components/form';

function App() {
  return (
    <div className="App">
      <div>
        <FormComponent/>
      {/* <Event name="Mahesh" age="22" salary="24000"></Event>
      <CEvent name="Monica" age="22"></CEvent> */}
       
        
      
      </div>
    </div>
  );
}

// class App extends Component
// {
//   constructor()
//   {
//     super();
//   }
//   render()
//   {
//     return (
      
//       <div>
//           <h1>React Js</h1>
//       </div>
      
//     );
//   }
// }
export default App;

