import logo from './logo.svg';
import './App.css';
import Student from './student';
import Poststd from './poststudent';
import Home from './home';
import { BrowserRouter as  Router,Switch, Route ,Link} from 'react-router-dom';


function App() {
  return (
    <Router>
      <div className='App'>
        <h1> React Router </h1>
        <ul className='Link' type='none'>
          <li> <Link to={'/'}>Home</Link></li>
          <li> <Link to={'/print'}>Add-Students</Link></li>
          <li> <Link to={'/Students'}>View-Students</Link></li>
        </ul>
        <hr/>
        <Switch>
              <Route exact path='/' component={Home} />
              <Route exact path='/print' component={Poststd} />
              <Route exact path='/Students' component={Student} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
