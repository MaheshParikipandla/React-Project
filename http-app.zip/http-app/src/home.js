import React, { Component } from 'react';
class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
                Welcome to Reouting
            </div>
         );
    }
}
 
export default Home;